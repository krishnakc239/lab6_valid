/**
 * 
 */
package com.students.domain;

import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @author B.Pirasanth
 *
 */
public class Phone implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Range(min = 100, max = 999)
	@Digits(integer = 3, fraction = 3,message = "{Size.Phone.areacode}")
 	private Integer area;
	@Range(min = 100,max = 999)
	@Digits(integer = 3, fraction = 3, message = "{Size.Phone.prefix}")
 	private Integer prefix;
	@Range(min = 1000,max = 9999)
 	@Digits(integer = 4, fraction = 4, message = "{Size.Phone.number}")
 	private Integer number;
	

 
	public Integer getArea() {
		return area;
	}

	public void setArea(Integer area) {
		this.area = area;
	}

 	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Integer getPrefix() {
		return prefix;
	}

	public void setPrefix(Integer prefix) {
		this.prefix = prefix;
	}
}
